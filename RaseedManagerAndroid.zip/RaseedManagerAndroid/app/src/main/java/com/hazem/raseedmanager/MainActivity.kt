package com.hazem.raseedmanager

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Typeface
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val SYRIAN_POUND = "ل.س"

class TxDb(context: Context) : SQLiteOpenHelper(context, "raseed_local.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE balances(company TEXT PRIMARY KEY, amount REAL NOT NULL DEFAULT 0)")
        db.execSQL("INSERT INTO balances(company, amount) VALUES('سيريتل',0),('MTN',0)")
        db.execSQL("""CREATE TABLE tx(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company TEXT NOT NULL,
            phone TEXT NOT NULL,
            amount REAL NOT NULL,
            commission REAL NOT NULL,
            created_at INTEGER NOT NULL
        )""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun balance(company: String): Double {
        readableDatabase.rawQuery("SELECT amount FROM balances WHERE company=?", arrayOf(company)).use {
            return if (it.moveToFirst()) it.getDouble(0) else 0.0
        }
    }
    fun setBalance(company: String, amount: Double) {
        val v = ContentValues().apply { put("company", company); put("amount", amount) }
        writableDatabase.insertWithOnConflict("balances", null, v, SQLiteDatabase.CONFLICT_REPLACE)
    }
    fun addTx(company: String, phone: String, amount: Double, commission: Double) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val v = ContentValues().apply {
                put("company", company); put("phone", phone); put("amount", amount)
                put("commission", commission); put("created_at", System.currentTimeMillis())
            }
            db.insert("tx", null, v)
            db.execSQL("UPDATE balances SET amount=amount-? WHERE company=?", arrayOf(amount, company))
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
    fun allTransactions(limit: Int = 100): List<Tx> {
        val out = mutableListOf<Tx>()
        readableDatabase.rawQuery(
            "SELECT id,company,phone,amount,commission,created_at FROM tx ORDER BY id DESC LIMIT ?",
            arrayOf(limit.toString())
        ).use { c ->
            while (c.moveToNext()) out.add(Tx(c.getLong(0), c.getString(1), c.getString(2), c.getDouble(3), c.getDouble(4), c.getLong(5)))
        }
        return out
    }
    fun totals(since: Long): Pair<Double, Int> {
        readableDatabase.rawQuery("SELECT COALESCE(SUM(commission),0), COUNT(*) FROM tx WHERE created_at>=?", arrayOf(since.toString())).use {
            return if (it.moveToFirst()) Pair(it.getDouble(0), it.getInt(1)) else Pair(0.0, 0)
        }
    }
    fun deleteTx(id: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.rawQuery("SELECT company,amount FROM tx WHERE id=?", arrayOf(id.toString())).use { c ->
                if (c.moveToFirst()) {
                    db.execSQL("UPDATE balances SET amount=amount+? WHERE company=?", arrayOf(c.getDouble(1), c.getString(0)))
                    db.delete("tx", "id=?", arrayOf(id.toString()))
                }
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}
data class Tx(val id: Long, val company: String, val phone: String, val amount: Double, val commission: Double, val time: Long)

class MainActivity : Activity() {
    private lateinit var db: TxDb
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var root: LinearLayout
    private lateinit var summary: TextView
    private lateinit var companySpinner: Spinner
    private lateinit var phoneInput: EditText
    private lateinit var amountInput: EditText
    private lateinit var commissionInput: EditText
    private lateinit var historyBox: LinearLayout
    private val companies = arrayOf("سيريتل", "MTN")
    private val money = java.text.DecimalFormat("#,##0.##")
    private fun fmt(v: Double) = money.format(v) + " " + SYRIAN_POUND
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = TxDb(this)
        prefs = getSharedPreferences("security", MODE_PRIVATE)
        if (prefs.getString("pin", null) == null) showPinSetup() else showPinLogin()
    }

    private fun showPinSetup() {
        val input = EditText(this).apply {
            hint = "أدخل PIN من 4 إلى 8 أرقام"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("إنشاء رمز حماية")
            .setMessage("أنشئ رمز PIN لحماية بيانات التطبيق على هذا الهاتف.")
            .setView(input).setCancelable(false)
            .setPositiveButton("حفظ") { _, _ ->
                val pin = input.text.toString()
                if (pin.length !in 4..8 || pin.any { !it.isDigit() }) {
                    toast("يجب أن يتكون الرمز من 4 إلى 8 أرقام")
                    showPinSetup()
                } else {
                    prefs.edit().putString("pin", pin).apply()
                    showMain()
                }
            }.show()
    }
    private fun showPinLogin() {
        val input = EditText(this).apply {
            hint = "رمز PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("إدارة الرصيد")
            .setMessage("أدخل رمز الحماية للمتابعة")
            .setView(input).setCancelable(false)
            .setPositiveButton("دخول") { _, _ ->
                if (input.text.toString() == prefs.getString("pin", "")) showMain()
                else { toast("الرمز غير صحيح"); showPinLogin() }
            }.show()
    }

    private fun showMain() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "إدارة تحويلات الرصيد"
            textSize = 24f; setTypeface(null, Typeface.BOLD)
            gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(16))
        }
        root.addView(title)
        summary = TextView(this).apply { textSize = 16f; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        root.addView(summary)
        addSection("تسجيل تحويل يدوي")
        companySpinner = Spinner(this)
        companySpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, companies)
        root.addView(companySpinner, matchWrap())
        phoneInput = edit("رقم هاتف الزبون", InputType.TYPE_CLASS_PHONE)
        amountInput = edit("قيمة التحويل (ل.س)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        commissionInput = edit("العمولة/الربح (ل.س)", InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL)
        addButton("حفظ التحويل") { saveTransaction() }
        addButton("تعديل الرصيد المتاح للشركة") { editBalance() }
        addButton("التقارير اليومية والشهرية") { showReports() }
        addButton("تغيير رمز PIN") { changePin() }
        addSection("آخر التحويلات")
        historyBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(historyBox)
        refresh()
    }

    private fun edit(hintText: String, type: Int): EditText {
        val e = EditText(this).apply {
            hint = hintText
            inputType = type
            textSize = 16f
            setSingleLine(true)
        }
        root.addView(e, matchWrap())
        return e
    }
    private fun addSection(text: String) {
        root.addView(TextView(this).apply {
            this.text = text; textSize = 18f; setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(16), 0, dp(8))
        })
    }
    private fun addButton(text: String, action: () -> Unit) {
        val b = Button(this).apply { this.text = text; isAllCaps = false; setOnClickListener { action() } }
        root.addView(b, matchWrap())
    }
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
        bottomMargin = dp(6)
    }
    private fun saveTransaction() {
        val company = companySpinner.selectedItem.toString()
        val phone = phoneInput.text.toString().trim()
        val amount = amountInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        val commission = commissionInput.text.toString().trim().replace(',', '.').toDoubleOrNull()
        if (phone.isBlank() || amount == null || amount <= 0 || commission == null || commission < 0) {
            toast("أدخل رقم الهاتف وقيمة تحويل صحيحة وعمولة صفر أو أكثر")
            return
        }
        if (amount > db.balance(company)) {
            AlertDialog.Builder(this).setTitle("الرصيد غير كافٍ")
                .setMessage("الرصيد المسجل لدى $company أقل من قيمة التحويل. يمكنك تعديل الرصيد أولاً.")
                .setPositiveButton("حسناً", null).show()
            return
        }
        db.addTx(company, phone, amount, commission)
        phoneInput.text.clear(); amountInput.text.clear(); commissionInput.text.clear()
        toast("تم حفظ التحويل وتحديث الرصيد")
        refresh()
    }
    private fun editBalance() {
        val company = companySpinner.selectedItem.toString()
        val input = EditText(this).apply {
            hint = "الرصيد الحالي الفعلي لدى $company"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText(db.balance(company).toString())
        }
        AlertDialog.Builder(this).setTitle("تعديل رصيد $company")
            .setMessage("أدخل الرصيد الفعلي المتاح الآن. سيستبدل الرقم المسجل.")
            .setView(input).setPositiveButton("حفظ") { _, _ ->
                val value = input.text.toString().trim().replace(',', '.').toDoubleOrNull()
                if (value == null || value < 0) toast("أدخل مبلغاً صحيحاً")
                else { db.setBalance(company, value); refresh(); toast("تم تحديث الرصيد") }
            }.setNegativeButton("إلغاء", null).show()
    }
    private fun showReports() {
        val now = System.currentTimeMillis()
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = now
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0); cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0); cal.set(java.util.Calendar.MILLISECOND, 0)
        val day = db.totals(cal.timeInMillis)
        cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
        val month = db.totals(cal.timeInMillis)
        val text = "تقرير اليوم\nعدد التحويلات: ${day.second}\nالعمولات المسجلة: ${fmt(day.first)}\n\n" +
            "تقرير الشهر الحالي\nعدد التحويلات: ${month.second}\nالعمولات المسجلة: ${fmt(month.first)}\n\n" +
            "رصيد سيريتل: ${fmt(db.balance("سيريتل"))}\nرصيد MTN: ${fmt(db.balance("MTN"))}\n\n" +
            "ملاحظة: الربح المعروض هو مجموع العمولات التي أدخلتها، وليس ربحاً صافياً بعد المصاريف."
        AlertDialog.Builder(this).setTitle("التقارير").setMessage(text).setPositiveButton("إغلاق", null).show()
    }
    private fun changePin() {
        val input = EditText(this).apply {
            hint = "PIN جديد (4–8 أرقام)"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this).setTitle("تغيير رمز PIN").setView(input)
            .setPositiveButton("حفظ") { _, _ ->
                val pin = input.text.toString()
                if (pin.length in 4..8 && pin.all { it.isDigit() }) {
                    prefs.edit().putString("pin", pin).apply(); toast("تم تغيير الرمز")
                } else toast("الرمز يجب أن يتكون من 4 إلى 8 أرقام")
            }.setNegativeButton("إلغاء", null).show()
    }
    private fun refresh() {
        summary.text = "الرصيد المتاح\nسيريتل: ${fmt(db.balance("سيريتل"))}\nMTN: ${fmt(db.balance("MTN"))}"
        historyBox.removeAllViews()
        val txs = db.allTransactions(50)
        if (txs.isEmpty()) {
            historyBox.addView(TextView(this).apply { text = "لا توجد تحويلات مسجلة بعد."; setPadding(0, dp(8), 0, dp(8)) })
        }
        txs.forEach { tx ->
            val date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale("ar")).format(Date(tx.time))
            val item = TextView(this).apply {
                text = "${tx.company} • ${tx.phone}\nالقيمة: ${fmt(tx.amount)} | العمولة: ${fmt(tx.commission)}\n$date\nاضغط مطولاً لحذف العملية واسترجاع رصيدها"
                textSize = 14f
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setBackgroundResource(android.R.drawable.dialog_holo_light_frame)
                setOnLongClickListener {
                    AlertDialog.Builder(this@MainActivity).setTitle("حذف التحويل؟")
                        .setMessage("سيتم حذف السجل وإعادة قيمة التحويل إلى الرصيد المسجل.")
                        .setPositiveButton("حذف") { _, _ -> db.deleteTx(tx.id); refresh(); toast("تم حذف العملية واسترجاع الرصيد") }
                        .setNegativeButton("إلغاء", null).show()
                    true
                }
            }
            historyBox.addView(item, matchWrap())
        }
    }
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
